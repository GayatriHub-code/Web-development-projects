document.addEventListener('DOMContentLoaded',()=>{
  const cityinput=document.getElementById("city-input");
  const btn=document.getElementById("get-weather-btn");
  const weatherinfo=document.getElementById("weather-info");
  const city_name=document.getElementById("city-name");
  const temp=document.getElementById("temperature");
  const description=document.getElementById("description");
  const error_msg=document.getElementById("error-message");
  const API_key="24e37bc04da97a16d1f254bce5c9ddba";
  btn.addEventListener('click',async()=>{
    const city=cityinput.value.trim();
    if(city==="") return;

    // it may throw an error
    // server/database is always in another continent
    try{
      const weatherdata=await fetch_weather_data(city);
      display_weather_data(weatherdata);

    }catch(error){
      show_error();
    }


  })
  async function fetch_weather_data(city){
    const url=`https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${API_key}`

    const response= await fetch(url);
    if(!response.ok){
      throw new Error("city not found");
    }
    const data=await response.json()
    return data;

  }
  function display_weather_data(data){
    const {name,main,weather}=data;
    city_name.textContent=name;
    
    temp.textContent=`Temperature : ${main.temp}`;
    description.textContent=`weather:${weather[0].description}`

    weatherinfo.classList.remove('hidden');
    error_msg.classList.add('hidden');


  }
  function show_error(){
    weatherinfo.classList.add('hidden');
    error_msg.classList.remove('hidden');

  }

})
