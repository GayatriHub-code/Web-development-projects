document.addEventListener('DOMContentLoaded',() =>{
      // to access the buttons we use document.get element by their id's
    const todoinput=document.getElementById("todo-input");
    const addtaskbtn=document.getElementById("add-task-btn");
    const todolist=document.getElementById("todo-list");

    // this array is used to store the tasks that we enter ,
    // it is stored in the form of dictionary [{..},{..}]
    let tasks=JSON.parse(localStorage.getItem('tasks')) || [];
    tasks.forEach((task)=> rendertasks(task));
    // this is the functionality that will happen when we click add task 
    addtaskbtn.addEventListener("click",function(){
      const tasktext= todoinput.value.trim();
      //  if we didn't eneter anything but still tries to add the task it will not take it and it will simply return it
      if(tasktext==="") return;
      //  this is an object which is stored in the tasks array when we add any task ..it adds tasks and 
      // in the backend it will add date,text,completed
      const newtask={
        id:Date.now(),
        text:tasktext ,
        completed:false
      }
      tasks.push(newtask);
      savetasks();
      rendertasks(newtask);
      // we will clear the input because next time when you type the new task it should not merge with the old task
      todoinput.value="";
      console.log(tasks);
    })
    function rendertasks(task){
      const li=document.createElement("li");
      li.setAttribute("data-id",task.id);
      if(task.completed) li.classList.add("completed");
      li.innerHTML=`<span>${task.text}</span>
      <button>delete</button>
      `;
      li.addEventListener('click',(e)=>{
        if(e.target.tagName==="BUTTON") return;
        task.completed=!task.completed;
        li.classList.toggle('completed');
        savetasks();
      });
      li.querySelector('button').addEventListener('click',(e)=>{
        e.stopPropagation()
        tasks=tasks.filter(t =>t.id !==task.id);
        li.remove();
        savetasks();
      })
      
      todolist.appendChild(li);

    }
    // to store the updates we use local storage 
    // this function is to add the updates to local storage
    function savetasks(){
        localStorage.setItem("tasks",JSON.stringify(tasks));
    }
})