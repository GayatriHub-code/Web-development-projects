document.addEventListener('DOMContentLoaded',()=>{
  const products=[
    {id:1, name:"clothes",price:185.99},
    {id:2, name:"food",price:125.99},
    {id:3, name:"chocolates",price:2589.9995},
  ]
  let cart=JSON.parse(localStorage.getItem("cart")) || [];
  const product_list=document.getElementById("product-list");
  const cart_items=document.getElementById("cart-items");
  const empty_cart=document.getElementById("empty-cart");
  const cart_total=document.getElementById("cart-total");
  const checkout_button=document.getElementById("checkout-btn");
  const total_price=document.getElementById("total-price");
    
  products.forEach(product =>{
    const productdiv=document.createElement('div');
    productdiv.classList.add('product');
    productdiv.innerHTML=`
    <span>${product.name} - $${product.price.toFixed(2)}</span>
    <button data-id="${product.id}">Add to cart</button>
  
    

    `
    product_list.appendChild(productdiv);
  });
  product_list.addEventListener('click',(e)=>{
    if(e.target.tagName==='BUTTON'){
     const product_id= parseInt(e.target.getAttribute('data-id'))
     const prod=products.find(p =>p.id===product_id);
     add_to_cart(prod);
    }
  })
 
  function add_to_cart(prod){
    cart.push(prod);
    localStorage.setItem("cart",JSON.stringify(cart));
    rendercart();
  }
  function rendercart(){
    cart_items.innerHTML="";
    let totalprice=0;
    if(cart.length>0){
      empty_cart.classList.add('hidden');
      cart_total.classList.remove('hidden');
      cart.forEach(item =>{
        totalprice+=item.price;
        const cartitem=document.createElement("div");
        cartitem.innerHTML=`
        ${item.name} - $${item.price.toFixed(2)}
        
        <button class="remove-btn">remove</button>
        `;
        cartitem.querySelector('.remove-btn').addEventListener('click',(e) =>{
          e.stopPropagation();
          cart=cart.filter(c =>c.id!== item.id);
          localStorage.setItem("cart",JSON.stringify(cart));
          rendercart();
          
        })

        
        cart_items.appendChild(cartitem);
        
      });
      total_price.textContent=totalprice;

    }else{
      empty_cart.classList.remove('hidden');
      total_price.textContent=`0.00`;
      
    }
    localStorage.setItem("cart",JSON.stringify(cart));
  }
  checkout_button.addEventListener('click',()=>{
    cart.length=0;
    localStorage.removeItem("cart");
    alert("successfully checkedout the items");
    rendercart();
  })
  rendercart();
})