document.addEventListener('DOMContentLoaded',()=>{
  const expense_form= document.getElementById('expense-form');
  const expense_name=document.getElementById('expense-name');
  const expense_amount=document.getElementById('expense-amount');
  const expense_list=document.getElementById('expense-list');
  const total_amount=document.getElementById('total-amount');


  let expenses=JSON.parse(localStorage.getItem('expenses')) || []
  let totalamount=calculate_total();
  renderexpenses();
  expense_form.addEventListener('submit',(e)=>{
    e.preventDefault();
    const name=expense_name.value.trim();
    const amount=parseFloat(expense_amount.value.trim());
    if(name!=="" && !isNaN(amount) && amount>0){
      const newexpense={
        id:Date.now(),
        name:name,
        amount:amount,
      }
      expenses.push(newexpense);
      
      save_expenses();
      renderexpenses();
      update_total();
      expense_name.value="";
      expense_amount.value="";
    }



  })
  function renderexpenses(){
    expense_list.innerHTML="";
    expenses.forEach(expense =>{
      const li=document.createElement('li');
      li.innerHTML=`
      ${expense.name} - $${expense.amount};

      <button data-id="${expense.id}">Delete</button>
      `;
      expense_list.appendChild(li);
    })
  }

  function calculate_total(){
    return expenses.reduce((sum,expense)=> sum+expense.amount,0)

  }
  function save_expenses(){
    localStorage.setItem('expenses',JSON.stringify(expenses));
  }



  function update_total(){
    totalamount=calculate_total();
    total_amount.textContent=totalamount.toFixed(2);
  }
   expense_list.addEventListener('click',(e)=>{
    if(e.target.tagName==='BUTTON'){
      const expense_id=parseInt(e.target.getAttribute('data-id'))
      expenses=expenses.filter(expense =>expense.id!==expense_id)
      save_expenses();
      renderexpenses();
      update_total();
    }
   })


})